 /********************************************************
     * Basic Nav Toggle
     ********************************************************/
    const nav = document.querySelector('nav');
    const navItems = nav.querySelectorAll('.nav-item');
    const sections = document.querySelectorAll('.section');
  
    // Function to display a given section based on its name
    function showSection(sectionName) {
      sections.forEach(section => {
        section.classList.remove('active');
      });
      const target = document.getElementById('section-' + sectionName);
      if (target) {
        target.classList.add('active');
      }
    }
  
    // Add click and drag-and-drop event listeners to each nav item
    navItems.forEach(item => {
      // CLICK handling for tab navigation
      item.addEventListener('click', function() {
        navItems.forEach(navItem => navItem.classList.remove('active'));
        this.classList.add('active');
        showSection(this.dataset.section);
      });
      
      // DRAG handling
      item.setAttribute('draggable', 'true');
      addDnDHandlers(item);
    });
  
    /**************** Drag and Drop Handlers ****************/
    let dragSrcEl = null;
    
    function handleDragStart(e) {
      dragSrcEl = this;
      e.dataTransfer.effectAllowed = 'move';
      // Some browsers require a setData for dragging to work
      e.dataTransfer.setData('text/plain', '');
      this.classList.add('dragging');
    }
  
    function handleDragOver(e) {
      if (e.preventDefault) e.preventDefault(); // Necessary to allow dropping
      e.dataTransfer.dropEffect = 'move';
      return false;
    }
  
    function handleDragEnter(e) {
      this.classList.add('over');
    }
  
    function handleDragLeave(e) {
      this.classList.remove('over');
    }
  
    function handleDrop(e) {
      if (e.stopPropagation) e.stopPropagation();
      // If dropping on a different element, swap positions in the nav container
      if (dragSrcEl !== this) {
        const parent = this.parentNode;
        const children = Array.from(parent.children);
        const draggedIndex = children.indexOf(dragSrcEl);
        const targetIndex = children.indexOf(this);
        if (draggedIndex < targetIndex) {
          parent.insertBefore(dragSrcEl, this.nextSibling);
        } else {
          parent.insertBefore(dragSrcEl, this);
        }
      }
      return false;
    }
  
    function handleDragEnd(e) {
      this.classList.remove('dragging');
      navItems.forEach(item => item.classList.remove('over'));
    }
  
    function addDnDHandlers(elem) {
      elem.addEventListener('dragstart', handleDragStart, false);
      elem.addEventListener('dragenter', handleDragEnter, false);
      elem.addEventListener('dragover', handleDragOver, false);
      elem.addEventListener('dragleave', handleDragLeave, false);
      elem.addEventListener('drop', handleDrop, false);
      elem.addEventListener('dragend', handleDragEnd, false);
    }
    

 /********************************************************
  * Life Score Increment (from Dashboard)
  ********************************************************/
 function incrementLifeScore() {
   const scoreEl = document.getElementById('lifeScore');
   let current = parseInt(scoreEl.textContent, 10);
   if (current < 100) {
     scoreEl.textContent = (++current).toString();
   }
 }

 /********************************************************
  * Log Exercise (from Activity)
  ********************************************************/
 function logExercise() {
   const exerciseType = document.getElementById('exerciseType').value.trim();
   const duration = document.getElementById('duration').value.trim();
   const messageEl = document.getElementById('activityMessage');
   if (exerciseType === '' || duration === '') {
     messageEl.style.color = 'red';
     messageEl.textContent = 'Please fill out both fields.';
     return;
   }
   messageEl.style.color = 'green';
   messageEl.textContent = `Successfully logged: ${exerciseType} for ${duration} minutes.`;
   // Clear form fields
   document.getElementById('exerciseType').value = '';
   document.getElementById('duration').value = '';
 }

 /********************************************************
  * Weight Tracking Update (from Body)
  ********************************************************/
 function submitWeight() {
   const weight = document.getElementById('currentWeight').value.trim();
   const msgEl = document.getElementById('weightMessage');
   if (weight === '') {
     msgEl.style.color = 'red';
     msgEl.textContent = 'Please enter your current weight.';
     return;
   }
   msgEl.style.color = 'green';
   msgEl.textContent = `Weight updated to ${weight} lbs.`;
   document.getElementById('currentWeight').value = '';
 }

 /********************************************************
  * Sleep Tracker Functionality
  ********************************************************/
 let sleepRecords = [];
 let editingIndex = -1;  // -1 indicates no record is being edited

 function calculateSleepDuration(sleepTime, wakeTime) {
   const [sleepHours, sleepMinutes] = sleepTime.split(':').map(Number);
   const [wakeHours, wakeMinutes] = wakeTime.split(':').map(Number);
   const sleepInMinutes = sleepHours * 60 + sleepMinutes;
   const wakeInMinutes = wakeHours * 60 + wakeMinutes;
   
   let durationInMinutes;
   // If wake time is earlier than sleep time, assume the record spans midnight.
   if (wakeInMinutes < sleepInMinutes) {
     durationInMinutes = (24 * 60 - sleepInMinutes) + wakeInMinutes;
   } else {
     durationInMinutes = wakeInMinutes - sleepInMinutes;
   }
   
   const hours = Math.floor(durationInMinutes / 60);
   const minutes = durationInMinutes % 60;
   return `${hours < 10 ? '0' + hours : hours}:${minutes < 10 ? '0' + minutes : minutes}`;
 }

 function updateEditingDuration() {
   const sleepInput = document.getElementById('editSleepTime');
   const wakeInput = document.getElementById('editWakeTime');
   const durationSpan = document.getElementById('editTotalDuration');
   if (sleepInput && wakeInput && durationSpan && sleepInput.value && wakeInput.value) {
     durationSpan.textContent = calculateSleepDuration(sleepInput.value, wakeInput.value);
   } else if (durationSpan) {
     durationSpan.textContent = '--:--';
   }
 }

 function renderSleepRecords() {
   const tableBody = document.getElementById('sleepRecordsTable');
   tableBody.innerHTML = '';
   sleepRecords.forEach((record, index) => {
     const row = document.createElement('tr');
     if (editingIndex === index) {
       // Edit Mode
       row.innerHTML = `
         <td><input type="time" id="editSleepTime" value="${record.sleepTime}" oninput="updateEditingDuration()"></td>
         <td><input type="time" id="editWakeTime" value="${record.wakeTime}" oninput="updateEditingDuration()"></td>
         <td><span id="editTotalDuration">${calculateSleepDuration(record.sleepTime, record.wakeTime)}</span></td>
         <td>
           <select id="editQuality">
             <option value="Good" ${record.quality === 'Good' ? 'selected' : ''}>Good</option>
             <option value="Moderate" ${record.quality === 'Moderate' ? 'selected' : ''}>Moderate</option>
             <option value="Poor" ${record.quality === 'Poor' ? 'selected' : ''}>Poor</option>
           </select>
         </td>
         <td><input type="text" id="editNotes" value="${record.notes}"></td>
         <td>
           <button class="action-btn save" onclick="saveEditingRecord(${index})">Save</button>
           <button class="action-btn cancel" onclick="cancelEditingRecord()">Cancel</button>
         </td>
       `;
     } else {
       // View Mode
       row.innerHTML = `
         <td><input type="time" readonly value="${record.sleepTime}"></td>
         <td><input type="time" readonly value="${record.wakeTime}"></td>
         <td>${calculateSleepDuration(record.sleepTime, record.wakeTime)}</td>
         <td>${record.quality}</td>
         <td>${record.notes}</td>
         <td>
           <button class="action-btn edit" onclick="editSleepRecord(${index})">Edit</button>
           <button class="action-btn delete" onclick="deleteSleepRecord(${index})">Delete</button>
         </td>
       `;
     }
     tableBody.appendChild(row);
   });
 }

 function editSleepRecord(index) {
   editingIndex = index;
   renderSleepRecords();
 }

 function saveEditingRecord(index) {
   const sleepInput = document.getElementById('editSleepTime');
   const wakeInput = document.getElementById('editWakeTime');
   const qualitySelect = document.getElementById('editQuality');
   const notesInput = document.getElementById('editNotes');
   
   if (!sleepInput.value || !wakeInput.value) {
     alert('Please fill in both the sleep and wake times.');
     return;
   }
   
   sleepRecords[index] = {
     sleepTime: sleepInput.value,
     wakeTime: wakeInput.value,
     quality: qualitySelect.value,
     notes: notesInput.value.trim()
   };
   
   editingIndex = -1;
   renderSleepRecords();
 }

 function cancelEditingRecord() {
   editingIndex = -1;
   renderSleepRecords();
 }

 function deleteSleepRecord(index) {
   sleepRecords.splice(index, 1);
   if (editingIndex === index) editingIndex = -1;
   renderSleepRecords();
 }

 function addSleepRecord() {
   const sleepTime = document.getElementById('sleepTime').value;
   const wakeTime = document.getElementById('wakeTime').value;
   const sleepQuality = document.getElementById('sleepQuality').value;
   const sleepNotes = document.getElementById('sleepNotes').value.trim();
   
   if (!sleepTime || !wakeTime) {
    //  alert('Please fill in both the sleep and wake times.');
     return;
   }
   
   sleepRecords.push({
     sleepTime: sleepTime,
     wakeTime: wakeTime,
     quality: sleepQuality,
     notes: sleepNotes
   });
   
   // Clear input fields
   document.getElementById('sleepTime').value = '';
   document.getElementById('wakeTime').value = '';
   document.getElementById('sleepQuality').selectedIndex = 0;
   document.getElementById('sleepNotes').value = '';
   
   renderSleepRecords();
 }

 // Hook up Sleep Tracker button click
 document.getElementById('saveSleepButton').addEventListener('click', addSleepRecord);

 /*************************************
  * Nutrition
  * ************************************* */
    let meals = [];
    let mealIdCounter = 0;

    function addMeal() {
      const mealNameInput = document.getElementById('mealName');
      const mealName = mealNameInput.value.trim();
      if (mealName === '') {
        alert('Please enter a meal name.');
        return;
      }
      const meal = { id: mealIdCounter++, name: mealName, ingredients: [] };
      meals.push(meal);
      mealNameInput.value = '';
      renderMeals();
    }

    function renderMeals() {
      const container = document.getElementById('mealsContainer');
      container.innerHTML = '';
      meals.forEach(meal => {
        const mealCard = document.createElement('div');
        mealCard.className = 'meal-card';
        mealCard.id = 'meal-' + meal.id;
        mealCard.innerHTML = `
          <h3>
            Meal: ${meal.name} 
            <button class="action-btn delete" onclick="deleteMeal(${meal.id})">Delete Meal</button>
          </h3>
          <div class="form-group">
            <input type="text" id="ingredientName-${meal.id}" placeholder="Ingredient Name" />
            <input type="number" id="calorieValue-${meal.id}" placeholder="Calories" min="0" />
            <button onclick="addIngredientToMeal(${meal.id})">Add Ingredient</button>
          </div>
          <table>
            <thead>
              <tr>
                <th>Ingredient</th>
                <th>Calories</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody id="ingredientsTable-${meal.id}">
            </tbody>
          </table>
          <p>Total Calories: <span id="totalCalories-${meal.id}">0</span></p>
        `;
        container.appendChild(mealCard);
        renderIngredients(meal.id);
      });
    }

    function addIngredientToMeal(mealId) {
      const ingredientNameInput = document.getElementById('ingredientName-' + mealId);
      const calorieValueInput = document.getElementById('calorieValue-' + mealId);
      const ingredientName = ingredientNameInput.value.trim();
      const calorieValue = calorieValueInput.value.trim();
      if (ingredientName === '' || calorieValue === '' || isNaN(calorieValue)) {
        alert('Please enter valid ingredient details.');
        return;
      }
      const meal = meals.find(m => m.id === mealId);
      if (!meal) return;
      meal.ingredients.push({ name: ingredientName, calories: parseFloat(calorieValue) });
      ingredientNameInput.value = '';
      calorieValueInput.value = '';
      renderIngredients(mealId);
    }

    function renderIngredients(mealId) {
      const meal = meals.find(m => m.id === mealId);
      if (!meal) return;
      const tbody = document.getElementById('ingredientsTable-' + mealId);
      tbody.innerHTML = '';
      let total = 0;
      meal.ingredients.forEach((ingredient, index) => {
        total += Number(ingredient.calories);
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${ingredient.name}</td>
          <td>${ingredient.calories}</td>
          <td>
            <button class="action-btn edit" onclick="editIngredient(${mealId}, ${index})">Edit</button>
            <button class="action-btn delete" onclick="deleteIngredient(${mealId}, ${index})">Delete</button>
          </td>
        `;
        tbody.appendChild(row);
      });
      document.getElementById('totalCalories-' + mealId).textContent = total;
    }

    function editIngredient(mealId, index) {
      const meal = meals.find(m => m.id === mealId);
      if (!meal) return;
      const current = meal.ingredients[index];
      const newName = prompt('Edit ingredient name:', current.name);
      const newCalories = prompt('Edit calorie value:', current.calories);
      if (newName !== null && newName.trim() !== '' && newCalories !== null && newCalories.trim() !== '' && !isNaN(newCalories)) {
        meal.ingredients[index].name = newName.trim();
        meal.ingredients[index].calories = parseFloat(newCalories);
        renderIngredients(mealId);
      }
    }

    function deleteIngredient(mealId, index) {
      const meal = meals.find(m => m.id === mealId);
      if (!meal) return;
      meal.ingredients.splice(index, 1);
      renderIngredients(mealId);
    }

    function deleteMeal(mealId) {
      meals = meals.filter(m => m.id !== mealId);
      renderMeals();
    }